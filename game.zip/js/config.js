var config = {
    bonus_point: 4,
    max : 2048,
}